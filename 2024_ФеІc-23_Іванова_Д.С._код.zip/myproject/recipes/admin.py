from django.contrib import admin
from .models import Recipe, Ingredient, CookingMethod, RecipeIngredient, DishCategory

@admin.register(CookingMethod)
class CookingMethodAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(Ingredient)
class IngredientAdmin(admin.ModelAdmin):
    list_display = ('name', 'unit')
    search_fields = ('name',)

class RecipeIngredientInline(admin.TabularInline):
    model = RecipeIngredient
    extra = 1

@admin.register(Recipe)
class RecipeAdmin(admin.ModelAdmin):
    list_display = ('title', 'cooking_method', 'calories_per_serving', 'servings')
    inlines = [RecipeIngredientInline]
    search_fields = ('title',)

@admin.register(DishCategory)
class DishCategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)