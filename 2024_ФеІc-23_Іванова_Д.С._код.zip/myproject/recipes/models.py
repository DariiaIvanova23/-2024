from django.db import models
from django.contrib.auth.models import User

class CookingMethod(models.Model):
    name = models.CharField(max_length=100, verbose_name="Назва")

    class Meta:
        verbose_name = "Спосіб приготування"
        verbose_name_plural = "Способи приготування"

    def __str__(self):
        return self.name

class Ingredient(models.Model):
    name = models.CharField(max_length=100, verbose_name="Назва")
    unit = models.CharField(max_length=20, verbose_name="Одиниця виміру")

    class Meta:
        verbose_name = "Інгредієнт"
        verbose_name_plural = "Інгредієнти"

    def __str__(self):
        return f"{self.name} ({self.unit})"

class DishCategory(models.Model):
    name = models.CharField(max_length=100, verbose_name="Назва")
    
    class Meta:
        verbose_name = "Категорія страви"
        verbose_name_plural = "Категорії страв"
    
    def __str__(self):
        return self.name

class Recipe(models.Model):
    title = models.CharField(max_length=200, verbose_name="Назва")
    category = models.ForeignKey(
        DishCategory,
        on_delete=models.CASCADE,
        verbose_name="Категорія",
        null=True,
        blank=True 
    )
    cooking_method = models.ForeignKey(
        CookingMethod, 
        on_delete=models.CASCADE,
        verbose_name="Спосіб приготування"
    )
    instructions = models.TextField(verbose_name="Інструкції")
    calories_per_serving = models.IntegerField(verbose_name="Калорій на порцію")
    servings = models.IntegerField(verbose_name="Кількість порцій")

    class Meta:
        verbose_name = "Рецепт"
        verbose_name_plural = "Рецепти"

    def __str__(self):
        return self.title

class RecipeIngredient(models.Model):
    recipe = models.ForeignKey(Recipe, on_delete=models.CASCADE)
    ingredient = models.ForeignKey(
        Ingredient, 
        on_delete=models.CASCADE,
        verbose_name="Інгредієнт"
    )
    quantity = models.IntegerField(verbose_name="Кількість")

    class Meta:
        verbose_name = "Інгредієнт рецепту"
        verbose_name_plural = "Інгредієнти рецепту"

class UserIngredient(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    ingredient = models.ForeignKey(Ingredient, on_delete=models.CASCADE)
    quantity = models.IntegerField(verbose_name="Кількість", default=0)

    class Meta:
        verbose_name = "Інгредієнт користувача"
        verbose_name_plural = "Інгредієнти користувача"

