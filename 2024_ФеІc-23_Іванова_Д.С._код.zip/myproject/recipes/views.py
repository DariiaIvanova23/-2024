from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from .models import Recipe, Ingredient, UserIngredient, RecipeIngredient, CookingMethod, DishCategory
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        
        if password == confirm_password:
            user = User.objects.create_user(username=username, password=password)
            login(request, user)
            return redirect('recipes:home')
            
    return render(request, 'recipes/register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('recipes:home')
    return render(request, 'recipes/login.html')

def logout_view(request):
    logout(request)
    return redirect('recipes:home')

def home(request):
    return render(request, 'recipes/home.html')

@login_required
def recipe_list(request):
    categories = DishCategory.objects.all()
    cooking_methods = CookingMethod.objects.all()
    selected_method = request.GET.get('cooking_method')
    if selected_method:
        recipes = Recipe.objects.filter(cooking_method_id=selected_method).order_by('category')
    else:
        recipes = Recipe.objects.all().order_by('category')
    user_ingredients = UserIngredient.objects.filter(user=request.user)
    user_ingredient_quantities = {ui.ingredient_id: ui.quantity for ui in user_ingredients}
    recipes_info = []
    for recipe in recipes:
        recipe_ingredients = RecipeIngredient.objects.filter(recipe=recipe)
        missing_ingredients = []
        for recipe_ingredient in recipe_ingredients:
            user_quantity = user_ingredient_quantities.get(recipe_ingredient.ingredient_id, 0)
            if user_quantity < recipe_ingredient.quantity:
                missing_ingredients.append({
                    'name': recipe_ingredient.ingredient.name,
                    'required': recipe_ingredient.quantity,
                    'available': user_quantity,
                    'unit': recipe_ingredient.ingredient.unit
                })
        recipes_info.append({
            'recipe': recipe,
            'missing_ingredients': missing_ingredients,
            'has_all_ingredients': len(missing_ingredients) == 0
        })
    return render(request, 'recipes/recipe_list.html', {
        'categories': categories,
        'recipes_info': recipes_info,
        'cooking_methods': cooking_methods,
        'selected_method': selected_method
    })

@login_required
def profile_view(request):
    all_ingredients = Ingredient.objects.all()

    user_ingredients = UserIngredient.objects.filter(user=request.user)
    
    user_ingredient_quantities = {ui.ingredient_id: ui.quantity for ui in user_ingredients}

    all_recipes = Recipe.objects.all()
    available_recipes = []
    
    for recipe in all_recipes:
        recipe_ingredients = RecipeIngredient.objects.filter(recipe=recipe)
        has_all_ingredients = True
        
        for recipe_ingredient in recipe_ingredients:
            user_quantity = user_ingredient_quantities.get(recipe_ingredient.ingredient_id, 0)
            if user_quantity < recipe_ingredient.quantity:
                has_all_ingredients = False
                break
        
        if has_all_ingredients:
            available_recipes.append(recipe)

    recipes_by_category = {}
    for recipe in available_recipes:
        category = recipe.category
        if category not in recipes_by_category:
            recipes_by_category[category] = []
        recipes_by_category[category].append(recipe)

    all_ingredients_json = [
        {
            'id': ingredient.id,
            'name': ingredient.name,
            'unit': ingredient.unit,
        }
        for ingredient in all_ingredients
    ]
    
    return render(request, 'recipes/profile.html', {
        'all_ingredients': all_ingredients_json,
        'user_ingredients': user_ingredients,
        'recipes_by_category': recipes_by_category
    })

@login_required
def add_ingredient(request):
    if request.method == 'POST':
        ingredient_id = request.POST.get('ingredient')
        quantity = request.POST.get('quantity', 0)
        
        try:
            quantity = int(quantity)
            if quantity <= 0:
                return redirect('recipes:profile')
        except (ValueError, TypeError):
            return redirect('recipes:profile')
        
        ingredient = get_object_or_404(Ingredient, id=ingredient_id)
        
        user_ingredient = UserIngredient.objects.filter(
            user=request.user, 
            ingredient=ingredient
        ).first()
        
        if user_ingredient:
            user_ingredient.quantity = quantity
            user_ingredient.save()
        else:
            UserIngredient.objects.create(
                user=request.user,
                ingredient=ingredient,
                quantity=quantity
            )
    return redirect('recipes:profile')

@login_required
@csrf_exempt
def update_ingredient_quantity(request, ingredient_id):
    if request.method == 'PATCH':
        try:
            data = json.loads(request.body)
            new_quantity = data.get('quantity')
            user_ingredient = UserIngredient.objects.get(id=ingredient_id)
            user_ingredient.quantity = new_quantity
            user_ingredient.save()
            return JsonResponse({'success': True})
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})
    return JsonResponse({'success': False, 'error': 'Invalid method'})

@login_required
@csrf_exempt
def remove_ingredient(request, ingredient_id):
    if request.method == 'DELETE':
        try:
            ingredient = get_object_or_404(
                UserIngredient, 
                id=ingredient_id,
                user=request.user
            )
            ingredient.delete()
            return JsonResponse({'status': 'success'})
        except UserIngredient.DoesNotExist:
            return JsonResponse(
                {'status': 'error', 'message': 'Ingredient not found'}, 
                status=404
            )
    return JsonResponse({'status': 'error'}, status=400)

def recipe_detail(request, recipe_id):
    recipe = get_object_or_404(Recipe, id=recipe_id)
    ingredients = RecipeIngredient.objects.filter(recipe=recipe)
    
    user_ingredients = {}
    if request.user.is_authenticated:
        user_ingredients = {
            ui.ingredient_id: ui.quantity 
            for ui in UserIngredient.objects.filter(user=request.user)
        }

    ingredients_info = []
    for ingredient in ingredients:
        user_quantity = user_ingredients.get(ingredient.ingredient_id, 0)
        ingredients_info.append({
            'ingredient': ingredient,
            'available': user_quantity,
            'has_enough': user_quantity >= ingredient.quantity
        })
    
    return render(request, 'recipes/recipe_detail.html', {
        'recipe': recipe,
        'ingredients_info': ingredients_info
    })