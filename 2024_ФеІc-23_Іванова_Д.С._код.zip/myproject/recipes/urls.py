from django.urls import path
from . import views

app_name = 'recipes'

urlpatterns = [
    path('', views.home, name='home'),
    path('recipes/', views.recipe_list, name='recipe_list'),
    path('recipe/<int:recipe_id>/', views.recipe_detail, name='recipe_detail'),
    path('profile/', views.profile_view, name='profile'),
    path('add-ingredient/', views.add_ingredient, name='add_ingredient'),
    path('remove-ingredient/<int:ingredient_id>/', views.remove_ingredient, name='remove_ingredient'),
    path('update-ingredient-quantity/<int:ingredient_id>/', views.update_ingredient_quantity, name='update_ingredient_quantity'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
]
